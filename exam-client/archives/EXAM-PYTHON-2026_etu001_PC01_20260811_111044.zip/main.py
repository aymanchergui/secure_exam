print("Hello exam")
