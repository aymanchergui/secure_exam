print("Hello SecureExam")
